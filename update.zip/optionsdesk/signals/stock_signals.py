"""Señales swing long-only para acciones argentinas (netas de costos, casino-free).

El scalping intradiario de acciones fue retirado a pedido: en AR las comisiones
(~1% + derechos + IVA por lado) se comen los movimientos chicos, así que el scalp
es casino. El foco es swing de varios días, donde el movimiento amortiza el costo.

Cada señal se filtra por R/R NETO de costos (`net_rr`): si después del ida-y-vuelta
de comisiones no deja edge, es perdedora estructural y no se muestra. Configurá tu
comisión real en STOCK_COMMISSION_PCT — el default (1%) es deliberadamente
conservador y filtra casi todo scalp/movimiento chico.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import datetime
from typing import Optional

import pandas as pd

from optionsdesk.config.costs import CostModel, DEFAULT_COSTS
from optionsdesk.data.providers.base import Quote

# R/R mínimo NETO de costos para emitir una señal. Por debajo, el ida-y-vuelta de
# comisiones se come el edge y la operación es perdedora estructural.
_MIN_NET_RR = 0.6
# No perseguir: un breakout ya extendido >5% sobre el pivote es entrada tardía
# (regla Minervini: comprar cerca del pivote, no arriba del envión).
_MAX_BREAKOUT_EXTENSION = 0.05


@dataclass(frozen=True)
class StockSignal:
    symbol: str
    strategy: str
    signal_type: str
    created_at: datetime
    entry_price: float
    stop_price: float
    target_price: float
    score: float
    rationale: str
    time_stop_min: Optional[int] = None
    max_holding_days: Optional[int] = None
    warnings: tuple[str, ...] = field(default_factory=tuple)
    cost_pct: float = 0.0   # ida-y-vuelta de costos como % de la entrada
    net_rr: float = 0.0     # recompensa/riesgo NETO de costos (el número que importa)
    # SMC enrichment (v2.4) — todos opcionales, backward-compatible
    pda_zone: Optional[str] = None           # "premium" | "discount" | "equilibrium"
    smc_structure: Optional[str] = None      # "BOS_UP" | "BOS_DOWN" | None
    nearest_liquidity: Optional[str] = None  # descripción del nivel más cercano
    adr_confluence: Optional[str] = None     # "confirmed" | "fx_driven" | "unknown"

    @property
    def risk_per_share(self) -> float:
        return max(self.entry_price - self.stop_price, 0.0)

    @property
    def rr(self) -> float:
        risk = self.risk_per_share
        return round((self.target_price - self.entry_price) / risk, 3) if risk > 0 else 0.0


def signal_grade(score: float) -> str:
    """Convierte un score 0-100 en un grade legible para el operador.

    S (≥88): confluencia SMC completa — sniper entry de libro.
    A (≥78): setup fuerte con SMC alignment.
    B (≥66): setup AT sólido, SMC parcial.
    C (≥52): señal marginal, operar con cautela.
    D (<52): ruido — no operar.
    """
    if score >= 88:
        return "S"
    if score >= 78:
        return "A"
    if score >= 66:
        return "B"
    if score >= 52:
        return "C"
    return "D"


def scan_stock_symbol(
    symbol: str,
    quote: Quote,
    *,
    daily: Optional[pd.DataFrame] = None,
    weekly: Optional[pd.DataFrame] = None,
    now: Optional[datetime] = None,
    costs: CostModel = DEFAULT_COSTS,
    bars_1m: Optional[pd.DataFrame] = None,   # aceptado por compatibilidad; swing no lo usa
    adaptive_context=None,                     # idem
) -> list[StockSignal]:
    """Señales swing long-only de acciones AR, netas de costos + contexto SMC.

    Orden de prioridad de setups (mayor a menor calidad):
    1. SMC_REVERSAL: stop-hunt de SSL + reversión (sniper entry del libro).
    2. SWING_TREND_PULLBACK: pullback a Keltner en tendencia sana.
    3. SWING_BREAKOUT: breakout Minervini con volumen y trend template.
    """
    current = now or datetime.now()
    if not _has_executable_book(quote):
        return []

    spot = float(quote.mid) if quote.mid > 0 else float(quote.last or 0.0)
    smc_enrichment = _build_smc_enrichment(symbol, quote, daily, weekly)
    smc_ctx = _smc_context_safe(daily, weekly, spot)

    # Setup SMC_REVERSAL: el de mayor calidad, detectado antes que los AT clásicos.
    smcrev_signals = _scan_smc_reversal(symbol.upper(), quote, daily, weekly, current, smc_ctx)

    out: list[StockSignal] = []

    # Procesar señales SMC_REVERSAL (ya tienen calidad garantizada)
    for sig in smcrev_signals:
        priced = _apply_costs(sig, costs)
        if priced.net_rr < _MIN_NET_RR * 0.8:   # umbral más bajo: el setup es de alta calidad
            continue
        if smc_enrichment:
            priced = replace(priced, **smc_enrichment)
        out.append(priced)

    # Setups AT clásicos filtrados y mejorados por SMC
    for sig in _scan_swings(symbol.upper(), quote, daily, weekly, current):
        if sig.risk_per_share <= 0 or sig.rr < 1.2:
            continue
        priced = _apply_costs(sig, costs)
        if priced.net_rr < _MIN_NET_RR:
            continue
        if smc_ctx is not None:
            delta, block, notes = _smc_quality(priced, smc_ctx, spot)
            if block is not None:
                continue
            if delta or notes:
                priced = replace(
                    priced,
                    score=round(min(max(priced.score + delta, 0.0), 100.0), 1),
                    rationale=priced.rationale + (f" | SMC: {', '.join(notes)}" if notes else ""),
                )
        if smc_enrichment:
            priced = replace(priced, **smc_enrichment)
        out.append(priced)

    return sorted(out, key=lambda s: (s.score, s.net_rr), reverse=True)


def _scan_smc_reversal(
    symbol: str,
    quote: "Quote",
    daily: Optional[pd.DataFrame],
    weekly: Optional[pd.DataFrame],
    now: datetime,
    smc_ctx,
) -> list["StockSignal"]:
    """Sniper entry del libro: stop-hunt de SSL + reversión alcista confirmada.

    Condiciones de activación (todas necesarias salvo indicado):
    - SSL fue barrido (low cruzó debajo del nivel) Y el precio cerró de vuelta arriba.
    - Al menos 1 confluencia adicional: OTE bullish, zona discount, BOS_UP, EMA stack.
    - Tendencia semanal alcista (filtro macro — no comprar contra la corriente).
    - Precio actual por encima del nivel del sweep (ya se revertió, no es el suelo).

    Stop: justo bajo el nivel del sweep (invalidación si lo vuelve a perder).
    Target: primer BSL no barrido por encima del spot.
    Score base 85 + up to 10 pts por confluencias adicionales.
    """
    if smc_ctx is None or daily is None or len(daily) < 20:
        return []

    sweeps = getattr(smc_ctx, "sweeps", [])
    ssl_reversals = [
        sw for sw in sweeps
        if getattr(sw, "direction", "") == "down"
        and getattr(sw, "reversed", False)
    ]
    if not ssl_reversals:
        return []

    entry = float(quote.ask) if quote.ask > 0 else float(quote.mid or quote.last or 0)
    if entry <= 0:
        return []

    # Confirmar tendencia semanal
    weekly_up = True
    if weekly is not None and len(weekly) >= 8:
        wclose = weekly["close"].astype(float)
        weekly_up = float(wclose.iloc[-1]) >= float(wclose.tail(10).mean()) * 0.97
    if not weekly_up:
        return []

    # El sweep más reciente determina el nivel del stop
    latest_sw  = max(ssl_reversals, key=lambda sw: getattr(sw, "bar_index", 0))
    ssl_level  = getattr(getattr(latest_sw, "level", None), "price", None)
    if ssl_level is None or ssl_level <= 0:
        return []

    # El precio actual debe haber rebotado por encima del nivel
    if entry <= ssl_level * 1.002:
        return []

    day  = _normalize_daily(daily)
    atr  = _atr(day)
    stop = max(ssl_level * 0.993, entry - 2.5 * atr)   # bajo el nivel del sweep

    # Target: primer BSL no barrido por encima del spot
    liquidity = getattr(smc_ctx, "liquidity", [])
    bsl_above = [
        lv for lv in liquidity
        if getattr(lv, "kind", "") == "BSL"
        and not getattr(lv, "swept", True)
        and getattr(lv, "price", 0) > entry * 1.01
    ]
    if bsl_above:
        target_lv   = min(bsl_above, key=lambda lv: lv.price)
        target      = target_lv.price
        target_note = f"BSL {target_lv.label} ${target_lv.price:,.0f}"
    else:
        target      = entry + 2.0 * atr
        target_note = f"2×ATR ${target:,.0f}"

    risk = entry - stop
    if risk <= 0 or (target - entry) < risk:
        return []

    # Score: base 85 + bonificaciones por confluencias
    score = 85.0
    conf_notes: list[str] = []

    ote = getattr(smc_ctx, "ote", None)
    pda = getattr(smc_ctx, "pda", None)
    mm  = getattr(smc_ctx, "mm", None)

    if ote is not None and getattr(ote, "direction", "") == "bullish":
        ote_lo, ote_hi = getattr(ote, "lo", 0), getattr(ote, "hi", 0)
        if ote_lo <= entry <= ote_hi:
            score += 5.0
            conf_notes.append("entrada en OTE 0.618-0.786")

    if pda is not None and getattr(pda, "zone", "") == "discount":
        score += 3.0
        conf_notes.append("zona discount PDA")

    if getattr(smc_ctx, "bos", "") == "BOS_UP":
        score += 2.0
        conf_notes.append("BOS alcista confirmado")

    if mm is not None and getattr(mm, "stack", "") == "bullish":
        score += 2.0
        conf_notes.append("EMAs alineadas alcistas")

    label_sw = getattr(getattr(latest_sw, "level", None), "label", "SSL")
    rationale = (
        f"Stop-hunt ${ssl_level:,.0f} ({label_sw}) + reversión alcista confirmada. "
        f"Target: {target_note}. R/R {(target-entry)/risk:.1f}:1."
    )
    if conf_notes:
        rationale += f" Confluencia: {', '.join(conf_notes)}."

    return [_stock_signal(
        symbol, "SWING", "SMC_REVERSAL", now,
        entry, stop, (target - entry) / risk,
        None, 8,
        round(min(score, 100.0), 1),
        rationale,
    )]


def _build_smc_enrichment(
    symbol: str,
    quote: Quote,
    daily: Optional[pd.DataFrame],
    weekly: Optional[pd.DataFrame],
) -> dict:
    """Calcula el contexto SMC para enriquecer StockSignal. Nunca lanza."""
    try:
        from optionsdesk.config.settings import settings as _s
        if not getattr(_s, "smc_enabled", True):
            return {}

        from optionsdesk.signals.smc import analyze_smc as _analyze_smc
        spot    = float(quote.mid) if quote.mid > 0 else float(quote.last or 0)
        smc_ctx = _analyze_smc(daily=daily, weekly=weekly, spot=spot)

        enrichment: dict = {}

        # Zona PDA
        pda = getattr(smc_ctx, "pda", None)
        if pda is not None:
            enrichment["pda_zone"] = getattr(pda, "zone", None)

        # Estructura (BOS)
        bos = getattr(smc_ctx, "bos", None)
        if bos:
            enrichment["smc_structure"] = bos

        # Nivel de liquidez más cercano al spot
        liquidity = getattr(smc_ctx, "liquidity", [])
        if liquidity and spot > 0:
            nearest = min(
                (lv for lv in liquidity if not getattr(lv, "swept", True)),
                key=lambda lv: abs(getattr(lv, "price", 0) - spot),
                default=None,
            )
            if nearest is not None:
                lv_p   = getattr(nearest, "price", 0.0)
                lv_k   = getattr(nearest, "kind", "")
                lv_lbl = getattr(nearest, "label", "")
                enrichment["nearest_liquidity"] = f"{lv_k} {lv_lbl} ${lv_p:,.0f}"

        # ADR confluence (Fase 2)
        if getattr(_s, "adr_ccl_enabled", False):
            from optionsdesk.data.providers.adr import (
                adr_daily as _adr_daily,
                adr_confluence as _adr_confluence,
                bos_to_dir as _bos_to_dir,
            )
            adr_map = _s.adr_map()
            if symbol.upper() in adr_map:
                adr_ticker, _ = adr_map[symbol.upper()]
                adr_df = _adr_daily(adr_ticker, days=20)
                conf   = _adr_confluence(_bos_to_dir(bos), adr_df)
                enrichment["adr_confluence"] = conf

        return enrichment
    except Exception as exc:
        import logging
        logging.getLogger(__name__).debug("_build_smc_enrichment(%s) fallo: %s", symbol, exc)
        return {}


def _smc_context_safe(daily, weekly, spot: float):
    """SmcContext para gatear la entrada (o None si SMC off / datos insuficientes).

    Nunca lanza: si algo falla, devuelve None y el swing opera como antes.
    """
    try:
        from optionsdesk.config.settings import settings as _s
        if not getattr(_s, "smc_enabled", True):
            return None
        if daily is None or len(daily) < 10 or spot <= 0:
            return None
        from optionsdesk.signals.smc import analyze_smc
        return analyze_smc(daily=daily, weekly=weekly, spot=spot)
    except Exception:
        return None


def _smc_quality(sig: StockSignal, ctx, spot: float) -> tuple[float, Optional[str], list[str]]:
    """Calidad SMC de un swing long → (delta_score, motivo_bloqueo, notas).

    Sólo bloquea ante contra-señal fuerte (ciclo MM bajista, o comprar pegado a una
    BSL sin barrer = resistencia sin recorrido). El resto suma/resta score para que
    las entradas con confluencia (descuento + OTE + stop hunt + ciclo) ranqueen
    arriba y las flojas abajo. No mata señales: las ordena y descarta la basura.
    """
    delta = 0.0
    notes: list[str] = []
    is_breakout = sig.signal_type == "SWING_BREAKOUT"
    is_pullback = sig.signal_type == "SWING_TREND_PULLBACK"

    # Gate duro: no comprar contra un ciclo MM claramente bajista.
    mm = getattr(ctx, "mm", None)
    if mm is not None and getattr(mm, "stack", "") == "bearish":
        return 0.0, "ciclo MM bajista (no comprar contra la corriente)", []

    # PDA premium/discount: clave para el PULLBACK (comprar value, no el techo).
    pda = getattr(ctx, "pda", None)
    if pda is not None and is_pullback:
        if pda.zone == "discount":
            delta += 12.0; notes.append("pullback en descuento (PDA)")
        elif pda.zone == "premium":
            delta -= 12.0; notes.append("pullback en premium (caro)")

    # OTE bullish (retroceso óptimo 0.618–0.786) para el pullback.
    ote = getattr(ctx, "ote", None)
    if is_pullback and ote is not None and getattr(ote, "direction", "") == "bullish" and spot > 0:
        if ote.lo <= spot <= ote.hi:
            delta += 10.0; notes.append("entrada en OTE 0.618–0.786")

    # Barrido SSL + reversión reciente (stop hunt alcista) — entrada de alta calidad.
    if any(
        getattr(sw, "direction", "") == "down" and getattr(sw, "reversed", False)
        for sw in (getattr(ctx, "sweeps", None) or [])
    ):
        delta += 8.0; notes.append("barrido SSL + reversión (stop hunt)")

    liquidity = getattr(ctx, "liquidity", None) or []
    if is_breakout:
        # Breakout que toma liquidez real (no un máximo en el vacío).
        if any(
            getattr(lv, "kind", "") == "BSL" and getattr(lv, "swept", False)
            and getattr(lv, "label", "") in ("PDH", "PWH", "EQH", "SWING_H")
            for lv in liquidity
        ):
            delta += 8.0; notes.append("breakout tomó liquidez BSL")
        # Gate duro: BSL mayor sin barrer pegada arriba = resistencia, sin recorrido.
        near_unswept = [
            lv for lv in liquidity
            if getattr(lv, "kind", "") == "BSL" and not getattr(lv, "swept", True)
            and spot > 0 and 0 < (lv.price - spot) / spot < 0.015
        ]
        if near_unswept:
            return 0.0, "BSL sin barrer <1.5% arriba (sin recorrido al objetivo)", []

    # Ciclo MM alcista confirma.
    if mm is not None and getattr(mm, "stack", "") == "bullish":
        delta += 5.0; notes.append("stack EMA alcista")

    return delta, None, notes


def _apply_costs(sig: StockSignal, costs: CostModel) -> StockSignal:
    """Adjunta el R/R neto del ida-y-vuelta de costos (comisión + derechos + IVA).

    El edge real de un swing es lo que queda DESPUÉS de pagar entrada y salida; una
    señal con rr bruto lindo pero costos altos puede ser perdedora estructural.
    """
    rt_cost = (
        costs.gross_cost(sig.entry_price, "stock_buy")
        + costs.gross_cost(sig.target_price, "stock_sell")
    )
    net_reward = (sig.target_price - sig.entry_price) - rt_cost
    net_risk = (sig.entry_price - sig.stop_price) + rt_cost
    net_rr = net_reward / net_risk if net_risk > 0 else 0.0
    cost_pct = rt_cost / sig.entry_price * 100.0 if sig.entry_price > 0 else 0.0
    return replace(sig, cost_pct=round(cost_pct, 3), net_rr=round(net_rr, 3))


def _scan_swings(
    symbol: str,
    quote: Quote,
    daily: Optional[pd.DataFrame],
    weekly: Optional[pd.DataFrame],
    now: datetime,
) -> list[StockSignal]:
    day = _normalize_daily(daily)
    week = _normalize_daily(weekly)
    if len(day) < 30:
        return []

    entry = float(quote.ask)
    if entry <= 0:
        return []

    close = day["close"].astype(float)
    high = day["high"].astype(float)
    low = day["low"].astype(float)
    volume = day["volume"].astype(float)
    sma20 = float(close.tail(20).mean())
    sma50 = float(close.tail(min(50, len(close))).mean())
    sma200 = float(close.tail(min(200, len(close))).mean())
    rsi = _rsi(close)
    atr = _atr(day)
    prior_close = float(close.iloc[-1])
    weekly_up = True
    if len(week) >= 8:
        wclose = week["close"].astype(float)
        weekly_up = float(wclose.iloc[-1]) >= float(wclose.tail(min(10, len(wclose))).mean()) * 0.98

    signals: list[StockSignal] = []

    # 1. Pullback a la banda inferior de Keltner (EMA20 - 2×ATR) en tendencia sana.
    lower_keltner = sma20 - (2.0 * atr)
    pullback_ok = (
        weekly_up
        and sma20 >= sma50 * 0.98
        and entry <= lower_keltner * 1.02     # precio tocando/cerca de la banda inferior
        and 30.0 <= rsi <= 60.0
        and entry >= prior_close * 1.001       # ya rebotando, no cuchillo cayendo
    )
    if pullback_ok:
        raw_stop = min(float(low.tail(5).min()), entry - max(atr, entry * 0.018))
        signals.append(_stock_signal(
            symbol,
            "SWING",
            "SWING_TREND_PULLBACK",
            now,
            entry,
            raw_stop,
            2.0,
            None,
            10,
            65.0 + min(max(lower_keltner / entry - 1.0, 0.0) * 1000.0, 15.0),
            f"Keltner pullback: precio cerca de la banda inferior en tendencia (RSI {rsi:.0f})",
        ))

    # 2. Breakout estilo Minervini (trend template) sobre el rango de 20 ruedas.
    prior_high = float(high.iloc[-21:-1].max()) if len(high) >= 21 else float(high.iloc[:-1].max())
    avg_vol = float(volume.tail(20).mean() or 0.0)
    vol_ok = avg_vol <= 0 or float(volume.iloc[-1]) >= avg_vol * 1.10
    trend_template_ok = (
        entry > sma200
        and sma50 > sma200
        and sma20 > sma50
        and entry > sma50
    )
    not_extended = entry <= prior_high * (1.0 + _MAX_BREAKOUT_EXTENSION)
    if (
        weekly_up
        and trend_template_ok
        and entry > prior_high * 1.001
        and not_extended
        and rsi < 75.0
        and vol_ok
    ):
        stop = entry - max(atr, entry * 0.018)
        signals.append(_stock_signal(
            symbol,
            "SWING",
            "SWING_BREAKOUT",
            now,
            entry,
            stop,
            2.0,
            None,
            10,
            64.0 + min((entry / prior_high - 1.0) * 900.0, 18.0),
            f"Breakout sobre rango de 20 ruedas con trend template y RSI {rsi:.0f}",
        ))
    return signals


def _stock_signal(
    symbol: str,
    strategy: str,
    signal_type: str,
    now: datetime,
    entry: float,
    stop: float,
    rr: float,
    time_stop_min: Optional[int],
    max_holding_days: Optional[int],
    score: float,
    rationale: str,
) -> StockSignal:
    risk = max(entry - stop, entry * 0.006)
    stop = min(stop, entry - entry * 0.003)
    target = entry + risk * rr
    return StockSignal(
        symbol=symbol,
        strategy=strategy,
        signal_type=signal_type,
        created_at=now,
        entry_price=round(entry, 4),
        stop_price=round(stop, 4),
        target_price=round(target, 4),
        score=round(min(max(score, 0.0), 100.0), 1),
        rationale=rationale,
        time_stop_min=time_stop_min,
        max_holding_days=max_holding_days,
    )


def _has_executable_book(quote: Quote) -> bool:
    return quote.bid > 0 and quote.ask > quote.bid and quote.mid > 0


def _normalize_daily(df: Optional[pd.DataFrame]) -> pd.DataFrame:
    columns = ["date", "open", "high", "low", "close", "volume"]
    if df is None or df.empty:
        return pd.DataFrame(columns=columns)
    out = df.copy()
    for col in columns:
        if col not in out.columns:
            out[col] = 0.0 if col != "date" else pd.NaT
    out["date"] = pd.to_datetime(out["date"], errors="coerce")
    for col in ("open", "high", "low", "close", "volume"):
        out[col] = pd.to_numeric(out[col], errors="coerce")
    return out[columns].dropna(subset=["date", "open", "high", "low", "close"]).sort_values("date").reset_index(drop=True)


def _rsi(close: pd.Series, n: int = 14) -> float:
    if len(close) < n + 1:
        return 50.0
    delta = close.diff()
    gain = delta.clip(lower=0).tail(n).mean()
    loss = (-delta.clip(upper=0)).tail(n).mean()
    if pd.isna(gain) or pd.isna(loss):
        return 50.0
    if loss <= 1e-9:
        return 100.0 if gain > 0 else 50.0
    rs = float(gain) / float(loss)
    return max(0.0, min(100.0, 100.0 - 100.0 / (1.0 + rs)))


def _atr(df: pd.DataFrame, n: int = 14) -> float:
    if df.empty:
        return 0.0
    hi = df["high"].astype(float)
    lo = df["low"].astype(float)
    cl = df["close"].astype(float)
    prev = cl.shift(1)
    tr = pd.concat([hi - lo, (hi - prev).abs(), (lo - prev).abs()], axis=1).max(axis=1)
    atr = float(tr.tail(min(n, len(tr))).median() or 0.0)
    spot = float(cl.iloc[-1] or 0.0)
    return max(atr, spot * 0.008) if spot > 0 else atr
