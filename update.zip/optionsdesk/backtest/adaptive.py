from dataclasses import dataclass

@dataclass
class AdaptiveContext:
    win_rate: float
    consecutive_losses: int
    trades_analyzed: int
    mode: str = "NORMAL"
    half_kelly_pct: float = 0.05

def analyze_performance(trades: list, limit: int = 20) -> AdaptiveContext:
    """Analyzes recent performance of any trades to adjust risk aggressiveness."""
    recent_trades = trades[-limit:]
    if not recent_trades:
        return AdaptiveContext(win_rate=0.5, consecutive_losses=0, trades_analyzed=0, mode="NORMAL")
    
    wins = sum(1 for t in recent_trades if getattr(t, "pnl_ars", 0) > 0)
    win_rate = wins / len(recent_trades)
    
    consecutive_losses = 0
    for t in reversed(recent_trades):
        if getattr(t, "pnl_ars", 0) <= 0:
            consecutive_losses += 1
        else:
            break
            
    mode = "NORMAL"
    if win_rate < 0.40 or consecutive_losses >= 3:
        mode = "DEFENSIVE"
    elif win_rate >= 0.60:
        mode = "AGGRESSIVE"

    # Calculate average reward/risk
    avg_rr = 2.0
    if wins > 0 and len(recent_trades) > wins:
        avg_win = sum(getattr(t, "pnl_ars", 0) for t in recent_trades if getattr(t, "pnl_ars", 0) > 0) / wins
        avg_loss = abs(sum(getattr(t, "pnl_ars", 0) for t in recent_trades if getattr(t, "pnl_ars", 0) <= 0) / (len(recent_trades) - wins))
        if avg_loss > 0:
            avg_rr = avg_win / avg_loss

    # Fractional Kelly (Half Kelly)
    # Kelly = W - ((1 - W) / R)
    kelly = win_rate - ((1.0 - win_rate) / avg_rr)
    half_kelly = max(min(kelly / 2.0, 0.15), 0.005) # Cap between 0.5% and 15%
    
    return AdaptiveContext(
        win_rate=win_rate,
        consecutive_losses=consecutive_losses,
        trades_analyzed=len(recent_trades),
        mode=mode,
        half_kelly_pct=half_kelly,
    )
